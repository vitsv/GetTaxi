﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Security;
using WebUI.Common;
using WebUI.Models;

namespace EOD.Filters
{
    /// <summary>
    /// Filter dla kontroli dostepu uzytkownikow wedlug zdefiniowanych praw
    /// </summary>
    public class CheckingRightsAttribute : AuthorizeAttribute
    {
        private int necessaryRights;

        public CheckingRightsAttribute(int rights)
        {
            necessaryRights = rights;
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            //najpierw sprawdzam czy uzytkownik jest zalogowany
            if (httpContext.Request.IsAuthenticated)
            {
                //teraz pobieram uprawnienia
                int uprawnienia = 0;

                //Pobieram i sprawdzam przepisane do uzytkownika role i uprawniwnia
                var cookie = httpContext
                        .Request
                        .Cookies[FormsAuthentication.FormsCookieName];

                if (null != cookie)
                {
                    var decrypted = FormsAuthentication.Decrypt(cookie.Value);

                    if (!string.IsNullOrEmpty(decrypted.UserData))
                    {
                        UserData userdata = Json.Decode<UserData>(decrypted.UserData);
                        uprawnienia = userdata.RightsSum;
                    }

                    return (uprawnienia & necessaryRights) == necessaryRights ? true : false;
                }
            }

            //domyslnie dostep jest zabroniony
            return false;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Request.IsAuthenticated)
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.Result = new JsonResult { Data = "_Denied_", JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                }
                else
                {
                    UrlHelper urlHelper = new UrlHelper(filterContext.RequestContext);
                    filterContext.Result = new RedirectResult(urlHelper.Action("AccessDenied", "Account", new { area = "" }));
                }
            }
            else
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.Result = new JsonResult { Data = "_Logon_", JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                }
                else
                {
                    UrlHelper urlHelper = new UrlHelper(filterContext.RequestContext);
                    string url = urlHelper.RequestContext.HttpContext.Request.Url.PathAndQuery;
                    filterContext.Result = new RedirectResult(urlHelper.Action("LogOn", "Account", new { area = "", returnUrl = url }));
                }
            }
        }

    }
}